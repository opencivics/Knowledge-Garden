---
id: 20241124192239
tags:
  - thesis
publish: "true"
release id:
---
# Towards an Open Civics

**CIVIC INFRASTRUCTURES AS ENABLING CONDITIONS FOR A VITAL RESILIENT, AND PARTICIPATORY CIVILIZATION**


# In Us We Trust

![[In Us We Trust]]

# Our Critical Path

![[Our Critical Path]]

![[OpenCivics Thesis/Open Civic Culture|Open Civic Culture]]


# Open Civic Culture

![[OpenCivics Thesis/Open Civic Culture|Open Civic Culture]]

# Open Civic Systems

![[OpenCivics Thesis/Open Civic Systems|Open Civic Systems]]

# Our Choice

![[Our Choice]]

# Acknowledgements

![[Acknowledgements]]

# Citations

![[Citations]]